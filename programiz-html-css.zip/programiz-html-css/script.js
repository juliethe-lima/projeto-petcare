<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PetCare - Página Inicial</title>
</head>
<body>

    <!-- Seu conteúdo HTML aqui -->

    <script src="script.js"></script>
</body>
</html>
// JavaScript para alternar classes de estilo no cabeçalho ao clicar
document.querySelector('header').addEventListener('click', function() {
    this.classList.toggle('destaque');
});
const produtos = [
    {
        id: 1,
        nome: "Ração para Cães",
        descricao: "Ração premium para cães de todas as raças e idades.",
        preco: 50.00,
        imagem: "caminho_para_imagem/racao_caes.jpg"
    },
    {
        id: 2,
        nome: "Brinquedo de Pelúcia",
        descricao: "Brinquedo de pelúcia para cães, resistente e durável.",
        preco: 15.00,
        imagem: "caminho_para_imagem/brinquedo_pelucia.jpg"
    },
    // Adicione mais produtos conforme necessário
];
